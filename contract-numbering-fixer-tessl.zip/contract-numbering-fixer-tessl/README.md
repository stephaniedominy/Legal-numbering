# contract-numbering-fixer (Tessl tile)

This folder maps the uploaded Claude skill into a Tessl tile/package layout.

## What to change before publishing

1. Edit `tile.json`
   - Replace `your-workspace` with the Tessl workspace you can publish to.
   - Bump `version` when you publish updates.
   - Set `private` to `false` only after you have approval to publish publicly.

2. Validate and publish with the Tessl CLI

```bash
# from this folder
# validate
npx tessl tile lint

# publish privately
npx tessl tile publish

# publish publicly after approval
npx tessl tile publish --public
```

## Notes

- The original skill content was preserved in `skills/contract-numbering-fixer/SKILL.md`.
- This skill is oriented toward Claude-style interactive document repair workflows, especially Google Docs in Chrome and `.docx` files.
- If you want stronger registry performance in Tessl, consider a follow-up edit to make the tool prerequisites more explicit and/or narrow the skill to `.docx` workflows.

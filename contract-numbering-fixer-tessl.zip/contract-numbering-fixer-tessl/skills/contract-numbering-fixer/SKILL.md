---
name: contract-numbering-fixer
description: >
  Review and fix numbering issues and incorrect cross-references in legal contracts and agreements.
  Use this skill whenever a user asks you to check, audit, fix, or clean up clause numbering,
  section numbers, or cross-references in any legal document — employment agreements, NDAs,
  service agreements, shareholder agreements, etc. Trigger when the user says things like
  "fix the numbering in my contract", "the clause references look wrong", "I made edits and
  now the numbers are off", "check for numbering issues", or uploads/links a contract and
  mentions anything about structure, numbering, or references being incorrect.
  Works with Google Docs (open in Chrome) and Word documents (.docx).
---

# Contract Numbering Fixer

You are helping the user review and repair two classes of problems that commonly appear in legal contracts after manual editing:

1. **Broken list numbering** — where automatic numbering has gone out of sync (e.g. a sub-clause shows as "1.1" when it should be "10.4", or clause numbers are duplicated/skipped)
2. **Stale cross-references** — where the body text says "see clause X" but clause X has been renumbered and now refers to the wrong thing

Work through both problems systematically and be thorough — a missed cross-reference in a contract can cause real confusion or legal ambiguity. That said, be careful not to create problems where none exist. The goal is to fix genuine errors, not to impose a style preference.

---

## Step 1: Identify the document

Ask the user for the document if they haven't provided it:
- **Google Doc**: they'll share a URL or it's already open in Chrome
- **Word file (.docx)**: they'll share a file path or upload it

If working with a Google Doc, use the Claude in Chrome tools to navigate to it and take a screenshot first to orient yourself.

If working with a .docx, use python-docx (install with `pip install python-docx --break-system-packages`) to inspect the document programmatically.

---

## Step 2: Build a clause map

Before fixing anything, build a complete map of the document's intended structure. Scroll through (or parse) the entire document and record:
- Every top-level clause number and heading (e.g. "10. Holiday Entitlement")
- Every sub-clause number and a short description of what the clause is about (e.g. "10.4 Carry-over of unused days")

For Google Docs, scroll through the entire document taking screenshots of each page to capture all clause numbers. For .docx, parse the full text programmatically.

This map is your ground truth — keep it accurate and refer back to it throughout.

**Watch for these signs of broken numbering:**
- A sub-clause that resets to "1.x" in the middle of a higher-numbered clause (e.g. "1.1" appearing inside clause 10)
- Duplicate clause numbers (two clauses both numbered "26.3")
- Skipped numbers (jumps from 26.2 to 26.4 with no 26.3)
- Empty or misplaced clauses (a clause heading followed immediately by the next clause heading, with no body text)
- Content that belongs to one clause embedded incorrectly as a sub-clause of another

---

## Step 3: Find all cross-references

Scan the document for every piece of text that references a clause by number. Common patterns:
- "clause X" / "clauses X and Y"
- "section X"
- "sub-clause X.Y"
- "in accordance with X"
- "pursuant to clause X"
- "as set out in X"
- "referred to in clause X"

For .docx files, use a regex search to extract all cross-references programmatically so you don't miss any.

---

## Step 4: Verify each cross-reference

This is the most important and most demanding step. For each cross-reference you find, you need to answer two questions:

**Question 1: Does the referenced clause exist?**
Check your clause map. If the number doesn't appear, that's a clear error — the clause was probably renumbered or deleted during editing.

**Question 2: Does the referenced clause describe what the text says it should?**
This is harder and requires you to actually read both clauses. The reference might point to an existing clause that nevertheless isn't the right one — for example, "subject to clause 10.7" where 10.7 says "The Company may replace untaken holiday with a payment" but the text is actually about carrying over holiday, and clause 10.6 "On termination, accrued holiday will be paid" is the better match.

To answer question 2, read the text surrounding the cross-reference and understand what it's trying to point to. Then read the referenced clause and ask: does this clause say what the reference implies it says? If the answer is no — and there's another clause nearby that fits better — flag this for the user's attention.

**What counts as an error vs. a style choice:**
- ✅ **Genuine error:** "see clause 16" when clause 16 doesn't exist but clause 15 is titled "Post-Termination Restrictions" and clearly matches
- ✅ **Genuine error:** "subject to clause 10.7" where 10.7 is about something unrelated, but nearby 10.6 matches perfectly
- ✅ **Genuine error:** "clause 1.1" where the numbering has changed and 1.1 is now something completely different
- ❌ **Not an error:** "clause 6" pointing to section 6 "Termination" — referencing a section by its top-level number is perfectly standard in legal drafting
- ❌ **Not an error:** "clauses 5 and 7 shall survive" pointing to the Confidentiality and Limitation of Liability sections — survival clauses routinely reference whole sections
- ❌ **Not an error:** "see clause 1.1" pointing to a definition, even if the wording could be more specific

The distinction matters: referencing a section by its top-level number (e.g. "clause 5" meaning the whole Confidentiality section) is normal and valid. You should only flag a reference if the clause it points to is clearly the wrong one or doesn't exist.

---

## Step 5: Fix cross-references

Fix stale cross-references using Find & Replace:

**In Google Docs:**
- Use Edit → Find and replace (or Ctrl+H)
- Replace the old clause reference with the new one
- Use "Replace" (not "Replace all") if the same number appears in other contexts where it should NOT be changed — check first

**In .docx:**
- Use python-docx to find and replace text across all paragraphs and runs
- Match the full phrase (e.g. "clause 10.6") rather than just the number to avoid accidentally changing unrelated numbers

Document every change you make in a running list so the user can review them at the end.

**When you're uncertain:** If a reference points to an existing clause but you're not sure whether it's the right one, don't change it — flag it for the user to check manually. Changing a correct reference is worse than leaving a possibly-wrong one in place.

---

## Step 6: Fix broken list numbering

**In Google Docs:**

Google Docs auto-numbering can break when items are manually inserted or when list continuation is lost. To fix:

- Right-click the mis-numbered item and look for "Restart numbering" or "Continue numbering"
- If the item should continue from the previous list item, choose "Continue numbering"
- If you need the list to restart at a specific number, use "Restart numbering" and set the value
- If the paragraph is in a completely different list from its neighbours (a common cause of "1.1" appearing in the middle of clause 10), you may need to delete and re-type the item, or cut and re-paste it so it joins the correct list

**Important:** When deleting or re-ordering list items, be very careful about selection. Select only the exact item(s) you intend to remove. After each deletion, take a screenshot and verify the surrounding clauses are intact — it's easy to accidentally delete the beginning of an adjacent clause when deleting a list item.

**In .docx:**

Use python-docx to:
- Identify paragraphs with `numId` list properties that have incorrect `ilvl` (indent level) or are members of the wrong numbering definition
- Reset the `numId` and `ilvl` on paragraphs that have been incorrectly assigned
- Or, if simpler, convert broken auto-numbered items to explicit text (e.g. "10.4  ...") if the document doesn't rely on dynamic list numbering elsewhere

---

## Step 7: Handle structural problems

Sometimes the real issue is that extra content was incorrectly embedded as list items when it shouldn't be. Common examples:
- A clause heading accidentally turned into a sub-clause (e.g. "Holidays and other paid leave" appearing as "26.4" when it should be a top-level heading)
- A duplicate version of a clause body appearing twice
- An empty list item creating a phantom clause number

To fix structural problems in Google Docs:
1. Screenshot the problem area first so you can see what's there
2. Identify exactly which paragraphs need to be deleted (use their visible numbers as anchors)
3. Click at the start of the first item to delete, then Shift+click at the end of the last item
4. Delete — then immediately screenshot to verify the result and that no adjacent content was lost
5. If content was accidentally deleted, use Ctrl+Z to undo immediately

---

## Step 8: Verify

After making all changes:

1. Rebuild your clause map from the corrected document and confirm every clause number is unique and sequential
2. Re-scan for cross-references and verify each one points to the right place
3. Pay special attention to cross-references near the clauses you changed

For Google Docs, scroll through the whole document one final time taking screenshots to confirm the numbering looks right throughout.

---

## Summary report

When done, give the user a clear summary:

**Changes made:**
- List each cross-reference that was updated (old → new)
- List each numbering fix (what was wrong, what it is now)
- List any structural changes (items removed, items moved)

**Things to manually check:**
- Any cross-references where you weren't sure which clause was the intended target
- Any references to parts of the document not visible in the excerpt you reviewed (e.g. references to Part 1 terms if only Part 2 was provided)
- Any references where the clause exists and is plausibly correct, but the content match felt uncertain

**If no issues were found:** Say so clearly and confidently. A clean document is a good outcome. Don't flag style preferences or precision improvements as errors.

---

## Tips from experience

- **Always take a screenshot before and after** structural changes in Google Docs — it's the fastest way to catch accidental deletions
- **"1.1" mid-document usually means a list break** — the paragraph joined a new list instead of continuing the existing one; fix it by re-joining the list
- **Ctrl+Z is your friend** — if something goes wrong in Google Docs, undo immediately before doing anything else
- **Find & Replace is safer than manual editing** for cross-references — manual edits can introduce typos
- **Check the end of the document too** — it's easy to focus on the obvious problems and miss a stale reference in the boilerplate near the end
- **When uncertain, preserve** — if you can't be confident a reference is wrong, leave it and flag it for the user rather than changing it to something that might also be wrong
